package com.hsbc.springaop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.hsbc.springaop.customer.bo.CustomerBo;
@Configuration
@ComponentScan("com.hsbc.springaop")
@EnableAspectJAutoProxy
public class App {
	public static void main(String[] args) throws Exception {

		ApplicationContext appContext = new AnnotationConfigApplicationContext(App.class);

		CustomerBo customer = (CustomerBo) appContext.getBean("customerBo");
		//customer.addCustomer();
		
		//customer.addCustomerReturnValue();
		
		//customer.addCustomerThrowException();
		
		customer.addCustomerAround("HSBC");

	}
}